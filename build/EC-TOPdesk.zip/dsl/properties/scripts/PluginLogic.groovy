

class PluginLogic {
    def processSomeProcedure(Map parameters) {
        println "Got parameters"
        println parameters

        // Do something

        return "some result"
    }
}


package EC::TOPdesk::Plugin;
use strict;
use warnings;

use base 'EC::RESTPlugin';
# This is the base plugin class. Use it to override/add certain methods if need arises.
1;